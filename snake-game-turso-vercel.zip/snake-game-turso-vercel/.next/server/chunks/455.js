"use strict";exports.id=455,exports.ids=[455],exports.modules={2017:(e,t,a)=>{a.d(t,{Ex:()=>T,tW:()=>r,wi:()=>o});var i=a(7395),n=a(306);let s={token_exchange:"换取 accessToken 失败",userinfo:"获取钉钉用户信息失败",profile:"钉钉用户信息不完整（缺 unionId）",db_upsert:"写入用户表失败",registration_disabled:"注册通道已关闭",unexpected:"未预期异常"};async function r(e,t,a){let s=String(t??"").slice(0,1e3);console.error(`[dingtalk-auth][${e}] ${s}`,a??"");try{await (0,n.a)();let t=(0,i.z)();await t.execute({sql:`INSERT INTO auth_failure_logs (stage, detail, meta)
            VALUES (?, ?, ?)`,args:[e,s,a?JSON.stringify(a).slice(0,2e3):null]}),await t.execute(`
      DELETE FROM auth_failure_logs
      WHERE id NOT IN (
        SELECT id FROM auth_failure_logs ORDER BY id DESC LIMIT 50
      )
    `)}catch(e){console.error("[dingtalk-auth] 诊断日志写入失败:",e)}}async function T(e=20){await (0,n.a)();let t=(0,i.z)();return(await t.execute({sql:`SELECT id, stage, detail, meta, created_at
          FROM auth_failure_logs
          ORDER BY id DESC
          LIMIT ?`,args:[e]})).rows.map(e=>{var t;return{id:Number(e.id),stage:String(e.stage),stageLabel:s[t=String(e.stage)]??t,detail:String(e.detail),meta:e.meta??null,createdAt:String(e.created_at)}})}async function o(){await (0,n.a)();let e=(0,i.z)();await e.execute("DELETE FROM auth_failure_logs")}},9178:(e,t,a)=>{a.d(t,{I8:()=>R,JX:()=>I,handlers:()=>p});var i=a(7866),n=a(772),s=a(2023),r=a.n(s),T=a(6113),o=a(7395),E=a(306),u=a(1809),l=a(2017),c=a(1067);let d=c.Ry({email:c.Z_().trim().toLowerCase().email("邮箱格式不正确"),password:c.Z_().min(6,"密码至少6位")}),N=process.env.AUTH_SECRET||process.env.NEXTAUTH_SECRET,_=process.env.DINGTALK_CLIENT_ID,L=process.env.DINGTALK_CLIENT_SECRET,I=!!(_&&L);async function w(e){try{return(await e.text()).slice(0,500)}catch{return"<无法读取响应体>"}}async function m(e){let t=(0,o.z)();await (0,E.a)();let a=(await t.execute({sql:"SELECT id, email, name FROM users WHERE dingtalk_union_id = ?",args:[e.unionId]})).rows[0];if(a)return e.nick&&e.nick!==a.name?(await t.execute({sql:"UPDATE users SET name = ? WHERE id = ?",args:[e.nick,a.id]}),{id:a.id,email:a.email,name:e.nick}):{id:a.id,email:a.email,name:a.name??"钉钉用户"};if(!await (0,u.I)())throw await (0,l.tW)("registration_disabled",`注册通道已关闭，拒绝新钉钉用户首登（unionId=${e.unionId}）`),Error("REGISTRATION_DISABLED");let i=(0,T.randomUUID)(),n=`dingtalk_${e.unionId}@users.noreply.local`,s=e.nick||"钉钉用户",c=await r().hash((0,T.randomUUID)()+(0,T.randomUUID)(),10);return await t.execute({sql:`INSERT INTO users (id, email, name, password_hash, dingtalk_union_id)
          VALUES (?, ?, ?, ?, ?)`,args:[i,n,s,c,e.unionId]}),{id:i,email:n,name:s}}let{handlers:p,auth:R,signIn:g,signOut:A}=(0,i.ZP)({secret:N,trustHost:!0,debug:"true"===process.env.AUTH_DEBUG,logger:{error(e){console.error("[nextauth][error]",e)},warn(e){console.warn("[nextauth][warn]",e)},debug(e,t){console.log("[nextauth][debug]",e,t)}},providers:[(0,n.Z)({credentials:{email:{label:"邮箱",type:"email"},password:{label:"密码",type:"password"}},async authorize(e){let t=d.safeParse(e);if(!t.success)return null;let{email:a,password:i}=t.data,n=(0,o.z)();try{let e=(await n.execute({sql:"SELECT id, email, name, password_hash FROM users WHERE email = ?",args:[a]})).rows[0];if(!e||!await r().compare(i,e.password_hash))return null;return{id:e.id,email:e.email,name:e.name}}catch(e){return console.error("认证错误:",e),null}}}),...I?[{id:"dingtalk",name:"钉钉",type:"oauth",clientId:_,clientSecret:L,checks:["state"],authorization:{url:"https://login.dingtalk.com/oauth2/auth",params:{response_type:"code",scope:"openid",prompt:"consent"}},token:{url:"https://api.dingtalk.com/v1.0/oauth2/userAccessToken",async request({params:e,provider:t}){let a;let i={clientId:t.clientId,clientSecret:t.clientSecret,code:e.code,grantType:"authorization_code"};try{a=await fetch("https://api.dingtalk.com/v1.0/oauth2/userAccessToken",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(i)})}catch(t){let e=t instanceof Error?t.message:String(t);throw await (0,l.tW)("token_exchange",`请求钉钉 token 接口网络异常: ${e}`),t}if(!a.ok){let e=await w(a);throw await (0,l.tW)("token_exchange",`钉钉返回 HTTP ${a.status}：${e}`,{status:a.status,body:e}),Error(`钉钉获取用户授权失败: HTTP ${a.status} ${e}`)}let n=await a.json();if(!n.accessToken){let e=JSON.stringify(n);throw await (0,l.tW)("token_exchange",`钉钉未返回 accessToken：${e}`,{body:e}),Error(`钉钉获取用户授权失败: ${e}`)}return{tokens:{access_token:n.accessToken,refresh_token:n.refreshToken}}}},userinfo:{url:"https://api.dingtalk.com/v1.0/contact/users/me",async request({tokens:e}){let t;try{t=await fetch("https://api.dingtalk.com/v1.0/contact/users/me",{headers:{"x-acs-dingtalk-access-token":String(e.access_token)}})}catch(t){let e=t instanceof Error?t.message:String(t);throw await (0,l.tW)("userinfo",`请求钉钉用户信息接口网络异常: ${e}`),t}if(!t.ok){let e=await w(t);throw await (0,l.tW)("userinfo",`钉钉用户信息接口返回 HTTP ${t.status}：${e}`,{status:t.status,body:e}),Error(`钉钉获取用户信息失败: HTTP ${t.status} ${e}`)}let a=await t.json();if(!a.unionId)throw await (0,l.tW)("profile",`钉钉用户信息缺少 unionId：${JSON.stringify(a).slice(0,300)}`),Error("钉钉用户信息缺少 unionId");return a}},profile:e=>({id:e.unionId,name:e.nick||"钉钉用户",email:e.email??`${e.unionId}@dingtalk.noreply.local`,image:e.avatarUrl??null})}]:[]],session:{strategy:"jwt"},pages:{signIn:"/login",error:"/login"},callbacks:{async jwt({token:e,user:t,account:a,profile:i}){if(t&&a?.provider==="dingtalk"){if(!i?.unionId)throw await (0,l.tW)("profile","jwt 回调未拿到 unionId"),Error("DINGTALK_PROFILE_MISSING");try{let t=await m({unionId:i.unionId,openId:i.openId,nick:i.nick,avatarUrl:i.avatarUrl,email:i.email});e.id=t.id,e.email=t.email,e.name=t.name}catch(t){let e=t instanceof Error?t.message:String(t);throw"REGISTRATION_DISABLED"!==e&&await (0,l.tW)("db_upsert",e,{unionId:i.unionId}),t}}else t&&(e.id=t.id,e.email=t.email);return e},session:async({session:e,token:t})=>(e.user&&(e.user.id=t.id,e.user.email=t.email),e)}})},7395:(e,t,a)=>{a.d(t,{z:()=>s});var i=a(7476);let n=null;function s(){if(!n){let e=process.env.TURSO_DATABASE_URL,t=process.env.TURSO_AUTH_TOKEN;if(!e)throw Error("TURSO_DATABASE_URL 环境变量未设置");n=(0,i.createClient)({url:e,authToken:t})}return n}},306:(e,t,a)=>{a.d(t,{a:()=>o});var i=a(7395);let n=null;async function s(){let e=(0,i.z)();await e.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      name TEXT,
      password_hash TEXT NOT NULL,
      dingtalk_union_id TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await r(),await e.execute(`
    CREATE TABLE IF NOT EXISTS quiz_questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      question TEXT NOT NULL,
      option_a TEXT NOT NULL,
      option_b TEXT NOT NULL,
      option_c TEXT NOT NULL,
      option_d TEXT NOT NULL,
      correct_index INTEGER NOT NULL CHECK (correct_index BETWEEN 0 AND 3),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS daily_credits (
      user_id TEXT NOT NULL,
      credit_date TEXT NOT NULL,
      credits INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (user_id, credit_date)
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS user_points (
      user_id TEXT PRIMARY KEY,
      total_points INTEGER NOT NULL DEFAULT 0,
      streak INTEGER NOT NULL DEFAULT 0,
      last_play_date TEXT,
      quiz_points_date TEXT,
      quiz_points_today INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS point_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      points INTEGER NOT NULL,
      reason TEXT NOT NULL,
      detail TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS auth_failure_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      stage TEXT NOT NULL,
      detail TEXT NOT NULL,
      meta TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE INDEX IF NOT EXISTS idx_quiz_questions_created
    ON quiz_questions(created_at)
  `),await T()}async function r(){let e=(0,i.z)();new Set((await e.execute("PRAGMA table_info(users)")).rows.map(e=>String(e.name))).has("dingtalk_union_id")||(await e.execute("ALTER TABLE users ADD COLUMN dingtalk_union_id TEXT"),console.log("users 表已补充 dingtalk_union_id 列")),await e.execute(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_users_dingtalk_union_id
    ON users(dingtalk_union_id)
  `)}async function T(){let e=(0,i.z)();await e.execute(`
    CREATE TABLE IF NOT EXISTS quiz_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      correct_count INTEGER NOT NULL,
      total_count INTEGER NOT NULL,
      passed INTEGER NOT NULL DEFAULT 0,
      attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);let t=new Set((await e.execute("PRAGMA table_info(quiz_attempts)")).rows.map(e=>String(e.name)));t.has("user_id")&&t.has("total_count")||(await e.execute("DROP TABLE IF EXISTS quiz_attempts_legacy"),await e.execute("ALTER TABLE quiz_attempts RENAME TO quiz_attempts_legacy"),await e.execute(`
      CREATE TABLE quiz_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        correct_count INTEGER NOT NULL,
        total_count INTEGER NOT NULL,
        passed INTEGER NOT NULL DEFAULT 0,
        attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `),console.warn("quiz_attempts 表结构已修正（旧表备份为 quiz_attempts_legacy）"))}function o(){return n||(n=s().catch(e=>{throw n=null,e})),n}},1809:(e,t,a)=>{a.d(t,{E:()=>T,I:()=>r});var i=a(7395),n=a(306);let s="registration_enabled";async function r(){await (0,n.a)();let e=(0,i.z)(),t=await e.execute({sql:"SELECT value FROM app_settings WHERE key = ?",args:[s]}),a=t.rows[0]?.value;return null==a||"1"===a||"true"===a}async function T(e){await (0,n.a)();let t=(0,i.z)();await t.execute({sql:`INSERT INTO app_settings (key, value, updated_at)
          VALUES (?, ?, datetime('now'))
          ON CONFLICT(key)
          DO UPDATE SET value = excluded.value, updated_at = datetime('now')`,args:[s,e?"1":"0"]})}}};
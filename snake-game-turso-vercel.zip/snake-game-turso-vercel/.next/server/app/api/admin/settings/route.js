"use strict";(()=>{var e={};e.id=80,e.ids=[80],e.modules={7476:e=>{e.exports=require("@libsql/client")},2934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},4580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},5869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},6113:e=>{e.exports=require("crypto")},1936:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>A,patchFetch:()=>_,requestAsyncStorage:()=>p,routeModule:()=>f,serverHooks:()=>L,staticGenerationAsyncStorage:()=>N});var a={};r.r(a),r.d(a,{GET:()=>T,PUT:()=>E,dynamic:()=>l});var n=r(9303),s=r(8716),o=r(670),i=r(7070),u=r(9157),d=r(1809),c=r(1067);let l="force-dynamic";async function T(){if(!await (0,u.DK)())return i.NextResponse.json({error:"未授权"},{status:401});try{let e=await (0,d.I)();return i.NextResponse.json({registrationEnabled:e})}catch(e){return console.error("获取设置错误:",e),i.NextResponse.json({error:"获取设置失败"},{status:500})}}async function E(e){if(!await (0,u.DK)())return i.NextResponse.json({error:"未授权"},{status:401});try{let t=await e.json(),r=c.Ry({registrationEnabled:c.O7()}).safeParse(t);if(!r.success)return i.NextResponse.json({error:"参数错误，需要布尔值 registrationEnabled"},{status:400});return await (0,d.E)(r.data.registrationEnabled),i.NextResponse.json({success:!0,registrationEnabled:r.data.registrationEnabled,message:r.data.registrationEnabled?"注册通道已开启":"注册通道已关闭"})}catch(e){return console.error("更新设置错误:",e),i.NextResponse.json({error:"更新设置失败"},{status:500})}}let f=new n.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/admin/settings/route",pathname:"/api/admin/settings",filename:"route",bundlePath:"app/api/admin/settings/route"},resolvedPagePath:"C:\\Users\\26003172\\WorkBuddy\\2026-09-09-14-26-19\\snake-game\\snake-game-turso-vercel\\app\\api\\admin\\settings\\route.ts",nextConfigOutput:"",userland:a}),{requestAsyncStorage:p,staticGenerationAsyncStorage:N,serverHooks:L}=f,A="/api/admin/settings/route";function _(){return(0,o.patchFetch)({serverHooks:L,staticGenerationAsyncStorage:N})}},9157:(e,t,r)=>{r.d(t,{DK:()=>d,KE:()=>c,jB:()=>o,oE:()=>u});var a=r(6113),n=r(1615);let s=process.env.ADMIN_PASSWORD||"admin112233sz",o="admin_token";function i(e){return(0,a.createHash)("sha256").update(`snake-admin:${e}`).digest("hex")}function u(e){return e===s}async function d(){let e=await (0,n.cookies)(),t=e.get(o)?.value;return!!t&&t===i(s)}function c(){return i(s)}},7395:(e,t,r)=>{r.d(t,{z:()=>s});var a=r(7476);let n=null;function s(){if(!n){let e=process.env.TURSO_DATABASE_URL,t=process.env.TURSO_AUTH_TOKEN;if(!e)throw Error("TURSO_DATABASE_URL 环境变量未设置");n=(0,a.createClient)({url:e,authToken:t})}return n}},306:(e,t,r)=>{r.d(t,{a:()=>u});var a=r(7395);let n=null;async function s(){let e=(0,a.z)();await e.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      name TEXT,
      password_hash TEXT NOT NULL,
      dingtalk_union_id TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await o(),await e.execute(`
    CREATE TABLE IF NOT EXISTS quiz_questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      question TEXT NOT NULL,
      option_a TEXT NOT NULL,
      option_b TEXT NOT NULL,
      option_c TEXT NOT NULL,
      option_d TEXT NOT NULL,
      correct_index INTEGER NOT NULL CHECK (correct_index BETWEEN 0 AND 3),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS daily_credits (
      user_id TEXT NOT NULL,
      credit_date TEXT NOT NULL,
      credits INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (user_id, credit_date)
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS user_points (
      user_id TEXT PRIMARY KEY,
      total_points INTEGER NOT NULL DEFAULT 0,
      streak INTEGER NOT NULL DEFAULT 0,
      last_play_date TEXT,
      quiz_points_date TEXT,
      quiz_points_today INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS point_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      points INTEGER NOT NULL,
      reason TEXT NOT NULL,
      detail TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS auth_failure_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      stage TEXT NOT NULL,
      detail TEXT NOT NULL,
      meta TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE INDEX IF NOT EXISTS idx_quiz_questions_created
    ON quiz_questions(created_at)
  `),await i()}async function o(){let e=(0,a.z)();new Set((await e.execute("PRAGMA table_info(users)")).rows.map(e=>String(e.name))).has("dingtalk_union_id")||(await e.execute("ALTER TABLE users ADD COLUMN dingtalk_union_id TEXT"),console.log("users 表已补充 dingtalk_union_id 列")),await e.execute(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_users_dingtalk_union_id
    ON users(dingtalk_union_id)
  `)}async function i(){let e=(0,a.z)();await e.execute(`
    CREATE TABLE IF NOT EXISTS quiz_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      correct_count INTEGER NOT NULL,
      total_count INTEGER NOT NULL,
      passed INTEGER NOT NULL DEFAULT 0,
      attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);let t=new Set((await e.execute("PRAGMA table_info(quiz_attempts)")).rows.map(e=>String(e.name)));t.has("user_id")&&t.has("total_count")||(await e.execute("DROP TABLE IF EXISTS quiz_attempts_legacy"),await e.execute("ALTER TABLE quiz_attempts RENAME TO quiz_attempts_legacy"),await e.execute(`
      CREATE TABLE quiz_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        correct_count INTEGER NOT NULL,
        total_count INTEGER NOT NULL,
        passed INTEGER NOT NULL DEFAULT 0,
        attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `),console.warn("quiz_attempts 表结构已修正（旧表备份为 quiz_attempts_legacy）"))}function u(){return n||(n=s().catch(e=>{throw n=null,e})),n}},1809:(e,t,r)=>{r.d(t,{E:()=>i,I:()=>o});var a=r(7395),n=r(306);let s="registration_enabled";async function o(){await (0,n.a)();let e=(0,a.z)(),t=await e.execute({sql:"SELECT value FROM app_settings WHERE key = ?",args:[s]}),r=t.rows[0]?.value;return null==r||"1"===r||"true"===r}async function i(e){await (0,n.a)();let t=(0,a.z)();await t.execute({sql:`INSERT INTO app_settings (key, value, updated_at)
          VALUES (?, ?, datetime('now'))
          ON CONFLICT(key)
          DO UPDATE SET value = excluded.value, updated_at = datetime('now')`,args:[s,e?"1":"0"]})}},1615:(e,t,r)=>{var a=r(8757);r.o(a,"cookies")&&r.d(t,{cookies:function(){return a.cookies}}),r.o(a,"headers")&&r.d(t,{headers:function(){return a.headers}})},3085:(e,t,r)=>{Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"DraftMode",{enumerable:!0,get:function(){return s}});let a=r(5869),n=r(6278);class s{get isEnabled(){return this._provider.isEnabled}enable(){let e=a.staticGenerationAsyncStorage.getStore();return e&&(0,n.trackDynamicDataAccessed)(e,"draftMode().enable()"),this._provider.enable()}disable(){let e=a.staticGenerationAsyncStorage.getStore();return e&&(0,n.trackDynamicDataAccessed)(e,"draftMode().disable()"),this._provider.disable()}constructor(e){this._provider=e}}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},8757:(e,t,r)=>{Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{cookies:function(){return T},draftMode:function(){return E},headers:function(){return l}});let a=r(8996),n=r(3047),s=r(2044),o=r(2934),i=r(3085),u=r(6278),d=r(5869),c=r(4580);function l(){let e="headers",t=d.staticGenerationAsyncStorage.getStore();if(t){if(t.forceStatic)return n.HeadersAdapter.seal(new Headers({}));(0,u.trackDynamicDataAccessed)(t,e)}return(0,c.getExpectedRequestStore)(e).headers}function T(){let e="cookies",t=d.staticGenerationAsyncStorage.getStore();if(t){if(t.forceStatic)return a.RequestCookiesAdapter.seal(new s.RequestCookies(new Headers({})));(0,u.trackDynamicDataAccessed)(t,e)}let r=(0,c.getExpectedRequestStore)(e),n=o.actionAsyncStorage.getStore();return(null==n?void 0:n.isAction)||(null==n?void 0:n.isAppRoute)?r.mutableCookies:r.cookies}function E(){let e=(0,c.getExpectedRequestStore)("draftMode");return new i.DraftMode(e.draftMode)}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},3047:(e,t,r)=>{Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{HeadersAdapter:function(){return s},ReadonlyHeadersError:function(){return n}});let a=r(8238);class n extends Error{constructor(){super("Headers cannot be modified. Read more: https://nextjs.org/docs/app/api-reference/functions/headers")}static callable(){throw new n}}class s extends Headers{constructor(e){super(),this.headers=new Proxy(e,{get(t,r,n){if("symbol"==typeof r)return a.ReflectAdapter.get(t,r,n);let s=r.toLowerCase(),o=Object.keys(e).find(e=>e.toLowerCase()===s);if(void 0!==o)return a.ReflectAdapter.get(t,o,n)},set(t,r,n,s){if("symbol"==typeof r)return a.ReflectAdapter.set(t,r,n,s);let o=r.toLowerCase(),i=Object.keys(e).find(e=>e.toLowerCase()===o);return a.ReflectAdapter.set(t,i??r,n,s)},has(t,r){if("symbol"==typeof r)return a.ReflectAdapter.has(t,r);let n=r.toLowerCase(),s=Object.keys(e).find(e=>e.toLowerCase()===n);return void 0!==s&&a.ReflectAdapter.has(t,s)},deleteProperty(t,r){if("symbol"==typeof r)return a.ReflectAdapter.deleteProperty(t,r);let n=r.toLowerCase(),s=Object.keys(e).find(e=>e.toLowerCase()===n);return void 0===s||a.ReflectAdapter.deleteProperty(t,s)}})}static seal(e){return new Proxy(e,{get(e,t,r){switch(t){case"append":case"delete":case"set":return n.callable;default:return a.ReflectAdapter.get(e,t,r)}}})}merge(e){return Array.isArray(e)?e.join(", "):e}static from(e){return e instanceof Headers?e:new s(e)}append(e,t){let r=this.headers[e];"string"==typeof r?this.headers[e]=[r,t]:Array.isArray(r)?r.push(t):this.headers[e]=t}delete(e){delete this.headers[e]}get(e){let t=this.headers[e];return void 0!==t?this.merge(t):null}has(e){return void 0!==this.headers[e]}set(e,t){this.headers[e]=t}forEach(e,t){for(let[r,a]of this.entries())e.call(t,a,r,this)}*entries(){for(let e of Object.keys(this.headers)){let t=e.toLowerCase(),r=this.get(t);yield[t,r]}}*keys(){for(let e of Object.keys(this.headers)){let t=e.toLowerCase();yield t}}*values(){for(let e of Object.keys(this.headers)){let t=this.get(e);yield t}}[Symbol.iterator](){return this.entries()}}},8238:(e,t)=>{Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"ReflectAdapter",{enumerable:!0,get:function(){return r}});class r{static get(e,t,r){let a=Reflect.get(e,t,r);return"function"==typeof a?a.bind(e):a}static set(e,t,r,a){return Reflect.set(e,t,r,a)}static has(e,t){return Reflect.has(e,t)}static deleteProperty(e,t){return Reflect.deleteProperty(e,t)}}},8996:(e,t,r)=>{Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{MutableRequestCookiesAdapter:function(){return l},ReadonlyRequestCookiesError:function(){return o},RequestCookiesAdapter:function(){return i},appendMutableCookies:function(){return c},getModifiedCookieValues:function(){return d}});let a=r(2044),n=r(8238),s=r(5869);class o extends Error{constructor(){super("Cookies can only be modified in a Server Action or Route Handler. Read more: https://nextjs.org/docs/app/api-reference/functions/cookies#cookiessetname-value-options")}static callable(){throw new o}}class i{static seal(e){return new Proxy(e,{get(e,t,r){switch(t){case"clear":case"delete":case"set":return o.callable;default:return n.ReflectAdapter.get(e,t,r)}}})}}let u=Symbol.for("next.mutated.cookies");function d(e){let t=e[u];return t&&Array.isArray(t)&&0!==t.length?t:[]}function c(e,t){let r=d(t);if(0===r.length)return!1;let n=new a.ResponseCookies(e),s=n.getAll();for(let e of r)n.set(e);for(let e of s)n.set(e);return!0}class l{static wrap(e,t){let r=new a.ResponseCookies(new Headers);for(let t of e.getAll())r.set(t);let o=[],i=new Set,d=()=>{let e=s.staticGenerationAsyncStorage.getStore();if(e&&(e.pathWasRevalidated=!0),o=r.getAll().filter(e=>i.has(e.name)),t){let e=[];for(let t of o){let r=new a.ResponseCookies(new Headers);r.set(t),e.push(r.toString())}t(e)}};return new Proxy(r,{get(e,t,r){switch(t){case u:return o;case"delete":return function(...t){i.add("string"==typeof t[0]?t[0]:t[0].name);try{e.delete(...t)}finally{d()}};case"set":return function(...t){i.add("string"==typeof t[0]?t[0]:t[0].name);try{return e.set(...t)}finally{d()}};default:return n.ReflectAdapter.get(e,t,r)}}})}}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[948,972,67],()=>r(1936));module.exports=a})();
"use strict";(()=>{var e={};e.id=776,e.ids=[776],e.modules={7476:e=>{e.exports=require("@libsql/client")},2934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},4580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},5869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},6113:e=>{e.exports=require("crypto")},3985:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>m,patchFetch:()=>g,requestAsyncStorage:()=>L,routeModule:()=>R,serverHooks:()=>y,staticGenerationAsyncStorage:()=>A});var s={};r.r(s),r.d(s,{DELETE:()=>_,GET:()=>p,POST:()=>f,PUT:()=>N,dynamic:()=>T});var n=r(9303),o=r(8716),a=r(670),i=r(7070),u=r(9157),c=r(7395),d=r(306),l=r(1067);let T="force-dynamic",E=l.Ry({question:l.Z_().trim().min(2,"题干至少2个字符"),options:l.IX(l.Z_().trim().min(1,"选项不能为空")).length(4,"必须提供4个选项"),correctAnswer:l.Rx().int().min(0).max(3)});async function p(){if(!await (0,u.DK)())return i.NextResponse.json({error:"未授权"},{status:401});try{await (0,d.a)();let e=(0,c.z)(),t=(await e.execute("SELECT id, question, option_a, option_b, option_c, option_d, correct_index, created_at FROM quiz_questions ORDER BY id DESC")).rows.map(e=>({id:e.id,question:e.question,options:[e.option_a,e.option_b,e.option_c,e.option_d],correctAnswer:Number(e.correct_index),createdAt:e.created_at}));return i.NextResponse.json({questions:t})}catch(e){return console.error("获取题目列表错误:",e),i.NextResponse.json({error:"获取题目失败"},{status:500})}}async function f(e){if(!await (0,u.DK)())return i.NextResponse.json({error:"未授权"},{status:401});try{let t=await e.json(),r=E.safeParse(t);if(!r.success)return i.NextResponse.json({error:r.error.errors[0].message},{status:400});let{question:s,options:n,correctAnswer:o}=r.data;await (0,d.a)();let a=(0,c.z)();return await a.execute({sql:`INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_index)
            VALUES (?, ?, ?, ?, ?, ?)`,args:[s,n[0],n[1],n[2],n[3],o]}),i.NextResponse.json({success:!0,message:"题目已添加"})}catch(e){return console.error("新增题目错误:",e),i.NextResponse.json({error:"新增失败，请重试"},{status:500})}}async function N(e){if(!await (0,u.DK)())return i.NextResponse.json({error:"未授权"},{status:401});try{let t=await e.json(),r=E.extend({id:l.Rx().int().positive()}).safeParse(t);if(!r.success)return i.NextResponse.json({error:r.error.errors[0].message},{status:400});let{id:s,question:n,options:o,correctAnswer:a}=r.data,u=(0,c.z)(),d=await u.execute({sql:`UPDATE quiz_questions
            SET question = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, correct_index = ?
            WHERE id = ?`,args:[n,o[0],o[1],o[2],o[3],a,s]});if(0===d.rowsAffected)return i.NextResponse.json({error:"题目不存在"},{status:404});return i.NextResponse.json({success:!0,message:"题目已更新"})}catch(e){return console.error("更新题目错误:",e),i.NextResponse.json({error:"更新失败，请重试"},{status:500})}}async function _(e){if(!await (0,u.DK)())return i.NextResponse.json({error:"未授权"},{status:401});try{let t=Number(new URL(e.url).searchParams.get("id"));if(!Number.isInteger(t)||t<=0)return i.NextResponse.json({error:"题目 ID 无效"},{status:400});let r=(0,c.z)(),s=await r.execute({sql:"DELETE FROM quiz_questions WHERE id = ?",args:[t]});if(0===s.rowsAffected)return i.NextResponse.json({error:"题目不存在"},{status:404});return i.NextResponse.json({success:!0,message:"题目已删除"})}catch(e){return console.error("删除题目错误:",e),i.NextResponse.json({error:"删除失败，请重试"},{status:500})}}let R=new n.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/admin/questions/route",pathname:"/api/admin/questions",filename:"route",bundlePath:"app/api/admin/questions/route"},resolvedPagePath:"C:\\Users\\26003172\\WorkBuddy\\2026-09-09-14-26-19\\snake-game\\snake-game-turso-vercel\\app\\api\\admin\\questions\\route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:L,staticGenerationAsyncStorage:A,serverHooks:y}=R,m="/api/admin/questions/route";function g(){return(0,a.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:A})}},9157:(e,t,r)=>{r.d(t,{DK:()=>c,KE:()=>d,jB:()=>a,oE:()=>u});var s=r(6113),n=r(1615);let o=process.env.ADMIN_PASSWORD||"admin112233sz",a="admin_token";function i(e){return(0,s.createHash)("sha256").update(`snake-admin:${e}`).digest("hex")}function u(e){return e===o}async function c(){let e=await (0,n.cookies)(),t=e.get(a)?.value;return!!t&&t===i(o)}function d(){return i(o)}},7395:(e,t,r)=>{r.d(t,{z:()=>o});var s=r(7476);let n=null;function o(){if(!n){let e=process.env.TURSO_DATABASE_URL,t=process.env.TURSO_AUTH_TOKEN;if(!e)throw Error("TURSO_DATABASE_URL 环境变量未设置");n=(0,s.createClient)({url:e,authToken:t})}return n}},306:(e,t,r)=>{r.d(t,{a:()=>u});var s=r(7395);let n=null;async function o(){let e=(0,s.z)();await e.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      name TEXT,
      password_hash TEXT NOT NULL,
      dingtalk_union_id TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await a(),await e.execute(`
    CREATE TABLE IF NOT EXISTS quiz_questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      question TEXT NOT NULL,
      option_a TEXT NOT NULL,
      option_b TEXT NOT NULL,
      option_c TEXT NOT NULL,
      option_d TEXT NOT NULL,
      correct_index INTEGER NOT NULL CHECK (correct_index BETWEEN 0 AND 3),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS daily_credits (
      user_id TEXT NOT NULL,
      credit_date TEXT NOT NULL,
      credits INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (user_id, credit_date)
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS user_points (
      user_id TEXT PRIMARY KEY,
      total_points INTEGER NOT NULL DEFAULT 0,
      streak INTEGER NOT NULL DEFAULT 0,
      last_play_date TEXT,
      quiz_points_date TEXT,
      quiz_points_today INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS point_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      points INTEGER NOT NULL,
      reason TEXT NOT NULL,
      detail TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS auth_failure_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      stage TEXT NOT NULL,
      detail TEXT NOT NULL,
      meta TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE INDEX IF NOT EXISTS idx_quiz_questions_created
    ON quiz_questions(created_at)
  `),await i()}async function a(){let e=(0,s.z)();new Set((await e.execute("PRAGMA table_info(users)")).rows.map(e=>String(e.name))).has("dingtalk_union_id")||(await e.execute("ALTER TABLE users ADD COLUMN dingtalk_union_id TEXT"),console.log("users 表已补充 dingtalk_union_id 列")),await e.execute(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_users_dingtalk_union_id
    ON users(dingtalk_union_id)
  `)}async function i(){let e=(0,s.z)();await e.execute(`
    CREATE TABLE IF NOT EXISTS quiz_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      correct_count INTEGER NOT NULL,
      total_count INTEGER NOT NULL,
      passed INTEGER NOT NULL DEFAULT 0,
      attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);let t=new Set((await e.execute("PRAGMA table_info(quiz_attempts)")).rows.map(e=>String(e.name)));t.has("user_id")&&t.has("total_count")||(await e.execute("DROP TABLE IF EXISTS quiz_attempts_legacy"),await e.execute("ALTER TABLE quiz_attempts RENAME TO quiz_attempts_legacy"),await e.execute(`
      CREATE TABLE quiz_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        correct_count INTEGER NOT NULL,
        total_count INTEGER NOT NULL,
        passed INTEGER NOT NULL DEFAULT 0,
        attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `),console.warn("quiz_attempts 表结构已修正（旧表备份为 quiz_attempts_legacy）"))}function u(){return n||(n=o().catch(e=>{throw n=null,e})),n}},1615:(e,t,r)=>{var s=r(8757);r.o(s,"cookies")&&r.d(t,{cookies:function(){return s.cookies}}),r.o(s,"headers")&&r.d(t,{headers:function(){return s.headers}})},3085:(e,t,r)=>{Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"DraftMode",{enumerable:!0,get:function(){return o}});let s=r(5869),n=r(6278);class o{get isEnabled(){return this._provider.isEnabled}enable(){let e=s.staticGenerationAsyncStorage.getStore();return e&&(0,n.trackDynamicDataAccessed)(e,"draftMode().enable()"),this._provider.enable()}disable(){let e=s.staticGenerationAsyncStorage.getStore();return e&&(0,n.trackDynamicDataAccessed)(e,"draftMode().disable()"),this._provider.disable()}constructor(e){this._provider=e}}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},8757:(e,t,r)=>{Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{cookies:function(){return T},draftMode:function(){return E},headers:function(){return l}});let s=r(8996),n=r(3047),o=r(2044),a=r(2934),i=r(3085),u=r(6278),c=r(5869),d=r(4580);function l(){let e="headers",t=c.staticGenerationAsyncStorage.getStore();if(t){if(t.forceStatic)return n.HeadersAdapter.seal(new Headers({}));(0,u.trackDynamicDataAccessed)(t,e)}return(0,d.getExpectedRequestStore)(e).headers}function T(){let e="cookies",t=c.staticGenerationAsyncStorage.getStore();if(t){if(t.forceStatic)return s.RequestCookiesAdapter.seal(new o.RequestCookies(new Headers({})));(0,u.trackDynamicDataAccessed)(t,e)}let r=(0,d.getExpectedRequestStore)(e),n=a.actionAsyncStorage.getStore();return(null==n?void 0:n.isAction)||(null==n?void 0:n.isAppRoute)?r.mutableCookies:r.cookies}function E(){let e=(0,d.getExpectedRequestStore)("draftMode");return new i.DraftMode(e.draftMode)}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},3047:(e,t,r)=>{Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{HeadersAdapter:function(){return o},ReadonlyHeadersError:function(){return n}});let s=r(8238);class n extends Error{constructor(){super("Headers cannot be modified. Read more: https://nextjs.org/docs/app/api-reference/functions/headers")}static callable(){throw new n}}class o extends Headers{constructor(e){super(),this.headers=new Proxy(e,{get(t,r,n){if("symbol"==typeof r)return s.ReflectAdapter.get(t,r,n);let o=r.toLowerCase(),a=Object.keys(e).find(e=>e.toLowerCase()===o);if(void 0!==a)return s.ReflectAdapter.get(t,a,n)},set(t,r,n,o){if("symbol"==typeof r)return s.ReflectAdapter.set(t,r,n,o);let a=r.toLowerCase(),i=Object.keys(e).find(e=>e.toLowerCase()===a);return s.ReflectAdapter.set(t,i??r,n,o)},has(t,r){if("symbol"==typeof r)return s.ReflectAdapter.has(t,r);let n=r.toLowerCase(),o=Object.keys(e).find(e=>e.toLowerCase()===n);return void 0!==o&&s.ReflectAdapter.has(t,o)},deleteProperty(t,r){if("symbol"==typeof r)return s.ReflectAdapter.deleteProperty(t,r);let n=r.toLowerCase(),o=Object.keys(e).find(e=>e.toLowerCase()===n);return void 0===o||s.ReflectAdapter.deleteProperty(t,o)}})}static seal(e){return new Proxy(e,{get(e,t,r){switch(t){case"append":case"delete":case"set":return n.callable;default:return s.ReflectAdapter.get(e,t,r)}}})}merge(e){return Array.isArray(e)?e.join(", "):e}static from(e){return e instanceof Headers?e:new o(e)}append(e,t){let r=this.headers[e];"string"==typeof r?this.headers[e]=[r,t]:Array.isArray(r)?r.push(t):this.headers[e]=t}delete(e){delete this.headers[e]}get(e){let t=this.headers[e];return void 0!==t?this.merge(t):null}has(e){return void 0!==this.headers[e]}set(e,t){this.headers[e]=t}forEach(e,t){for(let[r,s]of this.entries())e.call(t,s,r,this)}*entries(){for(let e of Object.keys(this.headers)){let t=e.toLowerCase(),r=this.get(t);yield[t,r]}}*keys(){for(let e of Object.keys(this.headers)){let t=e.toLowerCase();yield t}}*values(){for(let e of Object.keys(this.headers)){let t=this.get(e);yield t}}[Symbol.iterator](){return this.entries()}}},8238:(e,t)=>{Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"ReflectAdapter",{enumerable:!0,get:function(){return r}});class r{static get(e,t,r){let s=Reflect.get(e,t,r);return"function"==typeof s?s.bind(e):s}static set(e,t,r,s){return Reflect.set(e,t,r,s)}static has(e,t){return Reflect.has(e,t)}static deleteProperty(e,t){return Reflect.deleteProperty(e,t)}}},8996:(e,t,r)=>{Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{MutableRequestCookiesAdapter:function(){return l},ReadonlyRequestCookiesError:function(){return a},RequestCookiesAdapter:function(){return i},appendMutableCookies:function(){return d},getModifiedCookieValues:function(){return c}});let s=r(2044),n=r(8238),o=r(5869);class a extends Error{constructor(){super("Cookies can only be modified in a Server Action or Route Handler. Read more: https://nextjs.org/docs/app/api-reference/functions/cookies#cookiessetname-value-options")}static callable(){throw new a}}class i{static seal(e){return new Proxy(e,{get(e,t,r){switch(t){case"clear":case"delete":case"set":return a.callable;default:return n.ReflectAdapter.get(e,t,r)}}})}}let u=Symbol.for("next.mutated.cookies");function c(e){let t=e[u];return t&&Array.isArray(t)&&0!==t.length?t:[]}function d(e,t){let r=c(t);if(0===r.length)return!1;let n=new s.ResponseCookies(e),o=n.getAll();for(let e of r)n.set(e);for(let e of o)n.set(e);return!0}class l{static wrap(e,t){let r=new s.ResponseCookies(new Headers);for(let t of e.getAll())r.set(t);let a=[],i=new Set,c=()=>{let e=o.staticGenerationAsyncStorage.getStore();if(e&&(e.pathWasRevalidated=!0),a=r.getAll().filter(e=>i.has(e.name)),t){let e=[];for(let t of a){let r=new s.ResponseCookies(new Headers);r.set(t),e.push(r.toString())}t(e)}};return new Proxy(r,{get(e,t,r){switch(t){case u:return a;case"delete":return function(...t){i.add("string"==typeof t[0]?t[0]:t[0].name);try{e.delete(...t)}finally{c()}};case"set":return function(...t){i.add("string"==typeof t[0]?t[0]:t[0].name);try{return e.set(...t)}finally{c()}};default:return n.ReflectAdapter.get(e,t,r)}}})}}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[948,972,67],()=>r(3985));module.exports=s})();
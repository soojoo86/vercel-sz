"use strict";(()=>{var e={};e.id=569,e.ids=[569],e.modules={7476:e=>{e.exports=require("@libsql/client")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},6113:e=>{e.exports=require("crypto")},5066:(e,t,a)=>{a.r(t),a.d(t,{originalPathname:()=>U,patchFetch:()=>O,requestAsyncStorage:()=>p,routeModule:()=>l,serverHooks:()=>A,staticGenerationAsyncStorage:()=>R});var T={};a.r(T),a.d(T,{POST:()=>c});var i=a(9303),E=a(8716),s=a(670),r=a(7070),n=a(2023),o=a.n(n),u=a(1067),N=a(7395),L=a(6113),d=a(1809);let _=u.Ry({email:u.Z_().trim().toLowerCase().email("邮箱格式不正确"),password:u.Z_().min(6,"密码至少6位").max(72,"密码过长"),name:u.Z_().trim().max(30,"昵称最多30个字符").optional()});async function c(e){try{if(!await (0,d.I)())return r.NextResponse.json({error:"注册通道已关闭，请联系管理员"},{status:403});let t=await e.json(),a=_.safeParse(t);if(!a.success)return r.NextResponse.json({error:a.error.errors[0].message},{status:400});let{email:T,password:i,name:E}=a.data,s=(0,N.z)();if((await s.execute({sql:"SELECT id FROM users WHERE email = ?",args:[T]})).rows.length>0)return r.NextResponse.json({error:"该邮箱已被注册"},{status:400});let n=await o().hash(i,10),u=(0,L.randomUUID)();return await s.execute({sql:"INSERT INTO users (id, email, name, password_hash) VALUES (?, ?, ?, ?)",args:[u,T,E||null,n]}),r.NextResponse.json({message:"注册成功",userId:u},{status:201})}catch(e){return console.error("注册错误:",e),r.NextResponse.json({error:"注册失败，请稍后重试"},{status:500})}}let l=new i.AppRouteRouteModule({definition:{kind:E.x.APP_ROUTE,page:"/api/register/route",pathname:"/api/register",filename:"route",bundlePath:"app/api/register/route"},resolvedPagePath:"C:\\Users\\26003172\\WorkBuddy\\2026-09-09-14-26-19\\snake-game\\snake-game-turso-vercel\\app\\api\\register\\route.ts",nextConfigOutput:"",userland:T}),{requestAsyncStorage:p,staticGenerationAsyncStorage:R,serverHooks:A}=l,U="/api/register/route";function O(){return(0,s.patchFetch)({serverHooks:A,staticGenerationAsyncStorage:R})}},7395:(e,t,a)=>{a.d(t,{z:()=>E});var T=a(7476);let i=null;function E(){if(!i){let e=process.env.TURSO_DATABASE_URL,t=process.env.TURSO_AUTH_TOKEN;if(!e)throw Error("TURSO_DATABASE_URL 环境变量未设置");i=(0,T.createClient)({url:e,authToken:t})}return i}},306:(e,t,a)=>{a.d(t,{a:()=>n});var T=a(7395);let i=null;async function E(){let e=(0,T.z)();await e.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      name TEXT,
      password_hash TEXT NOT NULL,
      dingtalk_union_id TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await s(),await e.execute(`
    CREATE TABLE IF NOT EXISTS quiz_questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      question TEXT NOT NULL,
      option_a TEXT NOT NULL,
      option_b TEXT NOT NULL,
      option_c TEXT NOT NULL,
      option_d TEXT NOT NULL,
      correct_index INTEGER NOT NULL CHECK (correct_index BETWEEN 0 AND 3),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS daily_credits (
      user_id TEXT NOT NULL,
      credit_date TEXT NOT NULL,
      credits INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (user_id, credit_date)
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS user_points (
      user_id TEXT PRIMARY KEY,
      total_points INTEGER NOT NULL DEFAULT 0,
      streak INTEGER NOT NULL DEFAULT 0,
      last_play_date TEXT,
      quiz_points_date TEXT,
      quiz_points_today INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS point_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      points INTEGER NOT NULL,
      reason TEXT NOT NULL,
      detail TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE TABLE IF NOT EXISTS auth_failure_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      stage TEXT NOT NULL,
      detail TEXT NOT NULL,
      meta TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `),await e.execute(`
    CREATE INDEX IF NOT EXISTS idx_quiz_questions_created
    ON quiz_questions(created_at)
  `),await r()}async function s(){let e=(0,T.z)();new Set((await e.execute("PRAGMA table_info(users)")).rows.map(e=>String(e.name))).has("dingtalk_union_id")||(await e.execute("ALTER TABLE users ADD COLUMN dingtalk_union_id TEXT"),console.log("users 表已补充 dingtalk_union_id 列")),await e.execute(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_users_dingtalk_union_id
    ON users(dingtalk_union_id)
  `)}async function r(){let e=(0,T.z)();await e.execute(`
    CREATE TABLE IF NOT EXISTS quiz_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      correct_count INTEGER NOT NULL,
      total_count INTEGER NOT NULL,
      passed INTEGER NOT NULL DEFAULT 0,
      attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);let t=new Set((await e.execute("PRAGMA table_info(quiz_attempts)")).rows.map(e=>String(e.name)));t.has("user_id")&&t.has("total_count")||(await e.execute("DROP TABLE IF EXISTS quiz_attempts_legacy"),await e.execute("ALTER TABLE quiz_attempts RENAME TO quiz_attempts_legacy"),await e.execute(`
      CREATE TABLE quiz_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        correct_count INTEGER NOT NULL,
        total_count INTEGER NOT NULL,
        passed INTEGER NOT NULL DEFAULT 0,
        attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `),console.warn("quiz_attempts 表结构已修正（旧表备份为 quiz_attempts_legacy）"))}function n(){return i||(i=E().catch(e=>{throw i=null,e})),i}},1809:(e,t,a)=>{a.d(t,{E:()=>r,I:()=>s});var T=a(7395),i=a(306);let E="registration_enabled";async function s(){await (0,i.a)();let e=(0,T.z)(),t=await e.execute({sql:"SELECT value FROM app_settings WHERE key = ?",args:[E]}),a=t.rows[0]?.value;return null==a||"1"===a||"true"===a}async function r(e){await (0,i.a)();let t=(0,T.z)();await t.execute({sql:`INSERT INTO app_settings (key, value, updated_at)
          VALUES (?, ?, datetime('now'))
          ON CONFLICT(key)
          DO UPDATE SET value = excluded.value, updated_at = datetime('now')`,args:[E,e?"1":"0"]})}}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),T=t.X(0,[948,972,67,23],()=>a(5066));module.exports=T})();